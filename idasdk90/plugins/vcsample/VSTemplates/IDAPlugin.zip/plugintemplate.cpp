#include <ida.hpp>
#include <idp.hpp>
#include <name.hpp>
#include <frame.hpp>
#include <loader.hpp>
#include <kernwin.hpp>
#include <dbg.hpp>

struct plugin_ctx_t;


struct plugin_ctx_t : public plugmod_t
{

	virtual bool idaapi run(size_t arg) override
	{
		qnotused(arg);
		return true;
	}
};

static plugmod_t* idaapi init(void)
{
	return new plugin_ctx_t();
}

plugin_t PLUGIN =
{
  IDP_INTERFACE_VERSION,
  PLUGIN_MULTI,         // plugin flags
  init,                 // initialize
  nullptr,              // terminate. this pointer can be nullptr
  nullptr,              // invoke the plugin
  nullptr,              // long comment about the plugin
  nullptr,              // multiline help about the plugin
  nullptr,				// the preferred short name of the plugin
  nullptr				// the preferred hotkey to run the plugin
};